# 🧟 Hunter Zombies

Juego de zombies en 3D que corre directo en el navegador, con soporte multijugador.

## Cómo jugar

- **Online:** https://TU_USUARIO.github.io/hunter-zombies/ (después de activar GitHub Pages)
- **Local:** descarga el repo y abre `index.html` en tu navegador.

## Tecnologías

- [Three.js](https://threejs.org/) (r128) para los gráficos 3D
- [PeerJS](https://peerjs.com/) para el multijugador
- HTML, CSS y JavaScript en un solo archivo

## Nota

Necesita conexión a internet para cargar las librerías y la fuente desde CDN.
